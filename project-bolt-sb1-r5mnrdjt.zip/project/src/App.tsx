import React, { useState } from 'react';
import { Heart, RefreshCcw, ArrowLeft } from 'lucide-react';

interface Question {
  id: number;
  text: string;
  options: string[];
}

const questions: Question[] = [
  {
    id: 1,
    text: "What's your ideal way to spend a weekend?",
    options: [
      "Exploring nature and hiking",
      "Cozy indoor activities and reading",
      "Socializing with friends",
      "Creative pursuits and hobbies"
    ]
  },
  {
    id: 2,
    text: "How do you prefer to communicate in relationships?",
    options: [
      "Deep, meaningful conversations",
      "Actions and gestures",
      "Playful banter and humor",
      "Quality time together"
    ]
  },
  {
    id: 3,
    text: "What's your approach to life goals?",
    options: [
      "Ambitious and career-focused",
      "Balanced between work and personal life",
      "Living in the moment",
      "Following passion and creativity"
    ]
  },
  {
    id: 4,
    text: "How do you handle conflicts?",
    options: [
      "Open discussion and compromise",
      "Taking time to process alone",
      "Seeking immediate resolution",
      "Using humor to diffuse tension"
    ]
  },
  {
    id: 5,
    text: "What's your ideal date night?",
    options: [
      "Adventure and new experiences",
      "Romantic dinner at home",
      "Cultural events",
      "Spontaneous activities"
    ]
  },
  {
    id: 6,
    text: "How important is personal space to you?",
    options: [
      "Need regular alone time",
      "Balance of together and alone time",
      "Prefer constant companionship",
      "Flexible and adaptable"
    ]
  },
  {
    id: 7,
    text: "What role does family play in your life?",
    options: [
      "Very close-knit and traditional",
      "Independent but connected",
      "Creating chosen family",
      "Balanced with personal life"
    ]
  },
  {
    id: 8,
    text: "How do you express affection?",
    options: [
      "Verbal expressions and words",
      "Physical touch and closeness",
      "Acts of service and care",
      "Thoughtful gifts and surprises"
    ]
  },
  {
    id: 9,
    text: "What's your approach to future planning?",
    options: [
      "Detailed long-term plans",
      "Flexible general direction",
      "Living day by day",
      "Balance of planning and spontaneity"
    ]
  },
  {
    id: 10,
    text: "What qualities do you value most in a partner?",
    options: [
      "Intelligence and wit",
      "Emotional intelligence and empathy",
      "Ambition and drive",
      "Creativity and passion"
    ]
  }
];

function App() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<string[]>([]);
  const [showResult, setShowResult] = useState(false);

  const handleAnswer = (answer: string) => {
    const newAnswers = [...answers];
    newAnswers[currentQuestion] = answer;
    setAnswers(newAnswers);
    
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      generateResult(newAnswers);
      setShowResult(true);
    }
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  const generateResult = (allAnswers: string[]) => {
    setAnswers(allAnswers);
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setAnswers([]);
    setShowResult(false);
  };

  const generatePrompt = () => {
    const traits = [
      "compassionate",
      "adventurous",
      "intellectual",
      "creative",
      "nurturing",
      "passionate"
    ];
    
    const selectedTraits = traits.sort(() => 0.5 - Math.random()).slice(0, 3);
    
    return `A soulful portrait of a ${selectedTraits.join(", ")} person with a warm and inviting presence. The image should capture their authentic personality, with gentle lighting and natural elements that reflect harmony and connection. The setting should be intimate and meaningful, suggesting depth of character and emotional intelligence. Style: contemporary photography with soft, natural lighting. Mood: warm, inviting, and genuine.`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-100 to-teal-100 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full bg-white rounded-xl shadow-xl p-8">
        {!showResult ? (
          <>
            <div className="flex items-center justify-center mb-8">
              <Heart className="w-8 h-8 text-rose-500 mr-2" />
              <h1 className="text-3xl font-bold text-gray-800">Soulmate Quiz</h1>
            </div>
            <div className="mb-8">
              <div className="text-sm font-medium text-gray-500 mb-2">
                Question {currentQuestion + 1} of {questions.length}
              </div>
              <div className="h-2 w-full bg-gray-200 rounded-full">
                <div 
                  className="h-2 bg-rose-500 rounded-full transition-all duration-300"
                  style={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
                ></div>
              </div>
            </div>
            <h2 className="text-xl font-semibold text-gray-700 mb-6">
              {questions[currentQuestion].text}
            </h2>
            <div className="space-y-4">
              {questions[currentQuestion].options.map((option, index) => (
                <button
                  key={index}
                  onClick={() => handleAnswer(option)}
                  className={`w-full text-left p-4 rounded-lg border transition-all duration-200 ${
                    answers[currentQuestion] === option
                      ? 'border-rose-500 bg-rose-50'
                      : 'border-gray-200 hover:border-rose-500 hover:bg-rose-50'
                  }`}
                >
                  {option}
                </button>
              ))}
            </div>
            {currentQuestion > 0 && (
              <div className="mt-6">
                <button
                  onClick={handlePrevious}
                  className="inline-flex items-center px-4 py-2 text-rose-600 hover:text-rose-700 transition-colors duration-200"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Previous Question
                </button>
              </div>
            )}
          </>
        ) : (
          <div className="text-center">
            <h2 className="text-2xl font-bold text-gray-800 mb-6">Your Soulmate Prompt</h2>
            <div className="bg-gray-50 p-6 rounded-lg mb-8 text-left">
              <p className="text-gray-700 whitespace-pre-wrap">{generatePrompt()}</p>
            </div>
            <button
              onClick={resetQuiz}
              className="inline-flex items-center px-6 py-3 bg-rose-500 text-white rounded-lg hover:bg-rose-600 transition-colors duration-200"
            >
              <RefreshCcw className="w-5 h-5 mr-2" />
              Take Quiz Again
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;